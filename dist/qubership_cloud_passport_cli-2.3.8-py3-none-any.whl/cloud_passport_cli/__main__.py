from main import cli
cli()
