# Qubership cloud-passport-cli

---

Open-source python library of clients used by Qubership Cloud passport module.

## Installation

---

- Add the following section to your dependencies to add Qubership library as a dependency in your project (you can use any version starting from 2.3.4):
```
[tool.poetry.dependencies]
qubership-cloud-passport-cli = "2.3.4"
```
- Or you can install it via `pip`:
```
qubership-cloud-passport-cli = "2.3.4"
```